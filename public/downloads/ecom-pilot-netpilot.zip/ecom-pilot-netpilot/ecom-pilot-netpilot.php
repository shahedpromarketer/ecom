<?php
/**
 * Plugin Name:       Ecom Pilot Netpilot
 * Plugin URI:        https://netpilotdigital.com
 * Description:       Connect your WooCommerce store to Ecom Pilot CRM.
 * Version:           1.0.4
 * Author:            Netpilot Digital
 * Author URI:        https://netpilotdigital.com
 * License:           GPL-2.0+
 * Text Domain:       ecom-pilot-netpilot
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * WC requires at least: 6.0
 */

defined('ABSPATH') || exit;

define('EPN_VERSION', '1.0.4');

register_activation_hook(__FILE__, 'epn_activate');
register_deactivation_hook(__FILE__, 'epn_deactivate');

function epn_activate()   { epn_connect_to_crm(); }
function epn_deactivate() { epn_disconnect_from_crm(); }

// ── Admin Menu ────────────────────────────────────────────────────────────────

add_action('admin_menu', function () {
    add_options_page(
        'Ecom Pilot Netpilot',
        'Ecom Pilot',
        'manage_options',
        'ecom-pilot-netpilot',
        'epn_settings_page'
    );
});

// ── Settings Page ─────────────────────────────────────────────────────────────

function epn_settings_page() {
    if (!current_user_can('manage_options')) return;

    $notice      = '';
    $notice_type = 'info';

    if (isset($_POST['epn_save']) && check_admin_referer('epn_nonce')) {
        // Always save credentials first
        update_option('epn_crm_url',             esc_url_raw(rtrim(sanitize_text_field($_POST['epn_crm_url']), '/')));
        update_option('epn_api_key',             sanitize_text_field($_POST['epn_api_key']));
        update_option('epn_enable_ip_block',     isset($_POST['epn_enable_ip_block'])     ? 1 : 0);
        update_option('epn_enable_24h_limit',    isset($_POST['epn_enable_24h_limit'])    ? 1 : 0);
        update_option('epn_enable_double_block', isset($_POST['epn_enable_double_block']) ? 1 : 0);

        if (!$_POST['epn_crm_url'] || !$_POST['epn_api_key']) {
            $notice      = '⚠️ CRM URL এবং API Key অবশ্যই দিতে হবে।';
            $notice_type = 'warning';
        } else {
            $result = epn_connect_to_crm();

            if (!empty($result['success'])) {
                $notice      = '✅ সংযোগ সফল! ' . esc_html($result['site_name'] ?? 'Ecom Pilot CRM-এর সাথে connected।');
                $notice_type = 'success';
            } else {
                // Credentials saved — mark locally active so validations are attempted
                update_option('epn_connected', true);
                $notice      = '⚠️ Credentials saved কিন্তু CRM auto-connect হয়নি। CRM Dashboard → Integrations → WordPress → আপনার site-এর "Force Connect" button-এ click করুন।';
                $notice_type = 'warning';
            }
        }
    }

    $crm_url      = get_option('epn_crm_url', '');
    $api_key      = get_option('epn_api_key', '');
    $connected    = (bool) get_option('epn_connected', false);
    $ip_block     = get_option('epn_enable_ip_block',     1);
    $limit_24h    = get_option('epn_enable_24h_limit',    1);
    $double_block = get_option('epn_enable_double_block', 1);
    ?>
    <div class="wrap" style="max-width:620px;">
        <h1 style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
            <span style="font-size:24px;">⚡</span>
            Ecom Pilot Netpilot
            <?php if ($connected): ?>
            <span style="font-size:11px;font-weight:700;background:#dcfce7;color:#166534;padding:3px 10px;border-radius:20px;border:1px solid #86efac;letter-spacing:.3px;">● CONNECTED</span>
            <?php else: ?>
            <span style="font-size:11px;font-weight:700;background:#fee2e2;color:#991b1b;padding:3px 10px;border-radius:20px;border:1px solid #fca5a5;letter-spacing:.3px;">● NOT CONNECTED</span>
            <?php endif; ?>
        </h1>

        <?php if ($notice): ?>
        <div class="notice notice-<?php echo esc_attr($notice_type); ?> is-dismissible" style="margin:12px 0;">
            <p><?php echo $notice; ?></p>
        </div>
        <?php endif; ?>

        <form method="POST" style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:24px 28px;margin-top:14px;">
            <?php wp_nonce_field('epn_nonce'); ?>

            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:13px;font-weight:600;margin-bottom:5px;color:#374151;">CRM URL</label>
                <input type="url" name="epn_crm_url"
                       value="<?php echo esc_attr($crm_url); ?>"
                       placeholder="https://laravel.netpilotdigital.com"
                       style="width:100%;padding:9px 12px;border:1px solid #d1d5db;border-radius:7px;font-size:13px;box-sizing:border-box;" required>
            </div>

            <div style="margin-bottom:22px;">
                <label style="display:block;font-size:13px;font-weight:600;margin-bottom:5px;color:#374151;">API Key</label>
                <input type="text" name="epn_api_key"
                       value="<?php echo esc_attr($api_key); ?>"
                       placeholder="CRM → Integrations → Copy API Key"
                       style="width:100%;padding:9px 12px;border:1px solid #d1d5db;border-radius:7px;font-size:12px;font-family:monospace;box-sizing:border-box;" required>
                <p style="margin:4px 0 0;font-size:11px;color:#6b7280;">CRM → Integrations → WordPress → আপনার site-এর "Copy API Key" থেকে নিন</p>
            </div>

            <hr style="border:none;border-top:1px solid #f3f4f6;margin:0 0 18px;">

            <p style="font-size:13px;font-weight:700;color:#111827;margin:0 0 12px;">Fraud Protection</p>

            <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:22px;">

                <label style="display:flex;align-items:flex-start;gap:12px;padding:11px 14px;border:1px solid #e5e7eb;border-radius:8px;cursor:pointer;background:<?php echo $ip_block ? '#f0fdf4' : '#fff'; ?>;">
                    <input type="checkbox" name="epn_enable_ip_block" value="1"
                           <?php checked($ip_block, 1); ?>
                           onchange="this.closest('label').style.background=this.checked?'#f0fdf4':'#fff'"
                           style="margin-top:1px;width:15px;height:15px;accent-color:#16a34a;flex-shrink:0;">
                    <div>
                        <span style="font-size:13px;font-weight:600;color:#111827;">🛡️ IP Block</span>
                        <p style="margin:2px 0 0;font-size:11px;color:#6b7280;">Customer-এর IP address WordPress থেকে detect করে CRM-এ check হবে। Blocked IP থেকে order যাবে না।</p>
                    </div>
                </label>

                <label style="display:flex;align-items:flex-start;gap:12px;padding:11px 14px;border:1px solid #e5e7eb;border-radius:8px;cursor:pointer;background:<?php echo $limit_24h ? '#f0fdf4' : '#fff'; ?>;">
                    <input type="checkbox" name="epn_enable_24h_limit" value="1"
                           <?php checked($limit_24h, 1); ?>
                           onchange="this.closest('label').style.background=this.checked?'#f0fdf4':'#fff'"
                           style="margin-top:1px;width:15px;height:15px;accent-color:#16a34a;flex-shrink:0;">
                    <div>
                        <span style="font-size:13px;font-weight:600;color:#111827;">⏰ ২৪ ঘণ্টা Limit</span>
                        <p style="margin:2px 0 0;font-size:11px;color:#6b7280;">একই নম্বর থেকে ২৪ ঘণ্টায় মাত্র ১টি order করা যাবে।</p>
                    </div>
                </label>

                <label style="display:flex;align-items:flex-start;gap:12px;padding:11px 14px;border:1px solid #e5e7eb;border-radius:8px;cursor:pointer;background:<?php echo $double_block ? '#f0fdf4' : '#fff'; ?>;">
                    <input type="checkbox" name="epn_enable_double_block" value="1"
                           <?php checked($double_block, 1); ?>
                           onchange="this.closest('label').style.background=this.checked?'#f0fdf4':'#fff'"
                           style="margin-top:1px;width:15px;height:15px;accent-color:#16a34a;flex-shrink:0;">
                    <div>
                        <span style="font-size:13px;font-weight:600;color:#111827;">🚫 Double Order Block</span>
                        <p style="margin:2px 0 0;font-size:11px;color:#6b7280;">একই নম্বর থেকে অল্প সময়ের মধ্যে পরপর order করলে block হবে।</p>
                    </div>
                </label>

            </div>

            <button type="submit" name="epn_save"
                    style="background:#4f46e5;color:#fff;border:none;padding:10px 26px;border-radius:7px;font-size:14px;font-weight:600;cursor:pointer;letter-spacing:.2px;">
                💾 Save &amp; Connect
            </button>
        </form>
    </div>
    <?php
}

// ── HTTP helper — wp_remote_post with direct cURL fallback ────────────────────

function epn_http_post(string $url, array $headers, string $body, int $timeout = 10): array {
    // Try wp_remote_post first
    $response = wp_remote_post($url, [
        'timeout'     => $timeout,
        'sslverify'   => false,
        'redirection' => 3,
        'httpversion' => '1.1',
        'headers'     => $headers,
        'body'        => $body,
    ]);

    if (!is_wp_error($response)) {
        return [
            'code'  => (int) wp_remote_retrieve_response_code($response),
            'body'  => wp_remote_retrieve_body($response),
            'error' => null,
        ];
    }

    $wp_error_msg = $response->get_error_message();

    // Direct cURL fallback (bypasses WP HTTP layer)
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $header_lines = [];
        foreach ($headers as $k => $v) {
            $header_lines[] = "$k: $v";
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => $header_lines,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => min($timeout, 5),
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4,
        ]);
        $result = curl_exec($ch);
        $code   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err    = curl_error($ch);
        curl_close($ch);

        if ($result !== false && $code > 0) {
            return ['code' => $code, 'body' => $result, 'error' => null];
        }
        return ['code' => 0, 'body' => '', 'error' => $err ?: $wp_error_msg];
    }

    return ['code' => 0, 'body' => '', 'error' => $wp_error_msg];
}

// ── CRM Connect ───────────────────────────────────────────────────────────────

function epn_connect_to_crm(): array {
    $crm_url = rtrim(get_option('epn_crm_url', ''), '/');
    $api_key = get_option('epn_api_key', '');

    if (!$crm_url || !$api_key) {
        return ['success' => false, 'message' => 'CRM URL বা API Key দেওয়া নেই।'];
    }

    $res = epn_http_post(
        $crm_url . '/api/plugin/connect',
        ['X-API-KEY' => $api_key, 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
        wp_json_encode(['plugin_version' => EPN_VERSION]),
        8
    );

    if ($res['error']) {
        update_option('epn_connected', false);
        return ['success' => false, 'message' => 'Connection error: ' . $res['error']];
    }

    $body = json_decode($res['body'], true);

    if ($res['code'] === 200 && !empty($body['success'])) {
        update_option('epn_connected', true);
        return $body;
    }

    update_option('epn_connected', false);
    return ['success' => false, 'message' => $body['message'] ?? 'HTTP ' . $res['code']];
}

// ── CRM Disconnect ────────────────────────────────────────────────────────────

function epn_disconnect_from_crm(): void {
    $crm_url = rtrim(get_option('epn_crm_url', ''), '/');
    $api_key = get_option('epn_api_key', '');
    if (!$crm_url || !$api_key) return;

    epn_http_post(
        $crm_url . '/api/plugin/disconnect',
        ['X-API-KEY' => $api_key, 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
        '{}',
        8
    );

    update_option('epn_connected', false);
}

// ── Checkout Validation ───────────────────────────────────────────────────────

add_action('woocommerce_checkout_process', 'epn_validate_checkout');

function epn_validate_checkout() {
    $crm_url = rtrim(get_option('epn_crm_url', ''), '/');
    $api_key = get_option('epn_api_key', '');
    if (!$crm_url || !$api_key) return;

    $ip_block     = (bool) get_option('epn_enable_ip_block',     1);
    $limit_24h    = (bool) get_option('epn_enable_24h_limit',    1);
    $double_block = (bool) get_option('epn_enable_double_block', 1);

    if (!$ip_block && !$limit_24h && !$double_block) return;

    $phone = preg_replace('/[^0-9]/', '', sanitize_text_field($_POST['billing_phone'] ?? ''));

    $payload = [
        'phone'           => $phone,
        'ip'              => epn_client_ip(),
        'total'           => function_exists('WC') && WC()->cart ? (float) WC()->cart->get_total('edit') : 0,
        'check_ip'        => $ip_block,
        'check_24h'       => $limit_24h,
        'check_duplicate' => $double_block,
    ];

    $res = epn_http_post(
        $crm_url . '/api/plugin/validate-order',
        ['X-API-KEY' => $api_key, 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
        wp_json_encode($payload),
        3
    );

    if ($res['error'] || !$res['body']) return; // fail-open

    $body = json_decode($res['body'], true);
    if (isset($body['allowed']) && $body['allowed'] === false) {
        wc_add_notice($body['message'] ?? 'আপনার অর্ডার প্রক্রিয়া করা যাচ্ছে না।', 'error');
    }
}

// ── Push Order to CRM (always on, hidden) ────────────────────────────────────

add_action('woocommerce_checkout_order_created', 'epn_push_order');

function epn_push_order($order) {
    if (!get_option('epn_connected', false)) return;

    $crm_url = rtrim(get_option('epn_crm_url', ''), '/');
    $api_key = get_option('epn_api_key', '');
    if (!$crm_url || !$api_key) return;

    $line_items = [];
    foreach ($order->get_items() as $item) {
        $product      = $item->get_product();
        $line_items[] = [
            'id'       => $item->get_id(),
            'name'     => $item->get_name(),
            'sku'      => $product ? $product->get_sku() : '',
            'quantity' => $item->get_quantity(),
            'price'    => $product ? (float) $product->get_price() : 0,
            'subtotal' => (float) $item->get_subtotal(),
            'total'    => (float) $item->get_total(),
        ];
    }

    $payload = [
        'id'             => $order->get_id(),
        'billing'        => [
            'first_name' => $order->get_billing_first_name(),
            'last_name'  => $order->get_billing_last_name(),
            'phone'      => $order->get_billing_phone(),
            'state'      => $order->get_billing_state(),
            'city'       => $order->get_billing_city(),
            'address_1'  => $order->get_billing_address_1(),
            'address_2'  => $order->get_billing_address_2(),
        ],
        'total'          => (float) $order->get_total(),
        'subtotal'       => (float) $order->get_subtotal(),
        'discount_total' => (float) $order->get_discount_total(),
        'shipping_total' => (float) $order->get_shipping_total(),
        'payment_method' => $order->get_payment_method(),
        'customer_note'  => $order->get_customer_note(),
        'line_items'     => $line_items,
        'meta_data'      => [],
    ];

    // Non-blocking fire-and-forget
    epn_http_post(
        $crm_url . '/api/wordpress/sync',
        ['X-API-KEY' => $api_key, 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
        wp_json_encode($payload),
        10
    );
}

// ── Client IP (WordPress-side detection) ─────────────────────────────────────

function epn_client_ip(): string {
    $keys = [
        'HTTP_CF_CONNECTING_IP',   // Cloudflare
        'HTTP_X_FORWARDED_FOR',    // Proxy
        'HTTP_X_REAL_IP',          // Nginx
        'REMOTE_ADDR',
    ];
    foreach ($keys as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = trim(explode(',', $_SERVER[$key])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
    }
    // Fallback including private range IPs
    return trim(explode(',', $_SERVER['REMOTE_ADDR'] ?? '')[0]);
}
